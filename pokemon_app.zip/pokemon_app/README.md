# pokemon app

 Flutter project

buat pokedex pokemon sebagai tgs pertama mobile programming

825180069/arya hartono winarta